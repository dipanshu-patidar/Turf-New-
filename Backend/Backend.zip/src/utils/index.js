// Helper utilities
